package Domaci18;

public interface Racun {
    void printNamirnice();
    int printRacun();
    boolean jeNaspisku(Namirnice n);
}
